#define GAMEOVER_WIDTH 240
#define GAMEOVER_HEIGHT 160
const unsigned short gameover_data[38400];
