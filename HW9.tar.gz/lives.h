#define LIVES_WIDTH 10
#define LIVES_HEIGHT 10
const unsigned short lives_data[100];
