#define STARTSCREEN_WIDTH 240
#define STARTSCREEN_HEIGHT 160
const unsigned short startscreen_data[38400];
