#define FIGHTER_WIDTH 15
#define FIGHTER_HEIGHT 15
const unsigned short fighter_data[225];
