#define ENEMY3_WIDTH 15
#define ENEMY3_HEIGHT 15
const unsigned short enemy3_data[225];
