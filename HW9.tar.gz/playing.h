#define PLAYING_WIDTH 240
#define PLAYING_HEIGHT 160
const unsigned short playing_data[38400];
