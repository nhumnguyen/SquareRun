#define GAMEBOY_WIDTH 240
#define GAMEBOY_HEIGHT 160
const unsigned short gameboy_data[38400];
